<?php
namespace Logicrays\Contact\Block;

use Magento\Directory\Block\Data;
use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;

class ContactForm extends \Magento\Contact\Block\ContactForm
{
    /**
     * scopeConfig variable
     *
     * @var integer
     */
    public $scopeConfig;

    /**
     * Data variable
     *
     * @var \Magento\Directory\Block\Data
     */
    protected $directoryBlock;

   /**
    * __construct function
    *
    * @param ScopeConfigInterface $scopeConfig
    * @param Context $context
    * @param Data $directoryBlock
    * @param array $data
    */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Context $context,
        Data $directoryBlock,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->directoryBlock = $directoryBlock;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * GetCountries function
     *
     * @return array()
     */
    public function getCountries()
    {
        $country = $this->directoryBlock->getCountryHtmlSelect();
        return $country;
    }
    
    /**
     * GetRegion function
     *
     * @return array()
     */
    public function getRegion()
    {
        $region = $this->directoryBlock->getRegionHtmlSelect();
        return $region;
    }

    /**
     * GetCountryAction function
     *
     * @return string
     */
    public function getCountryAction()
    {
        return $this->getUrl('contact/index/country', ['_secure' => true]);
    }

    /**
     * GetFormAction function
     *
     * @return void
     */
    public function getFormAction()
    {
        return $this->getUrl('contact/index/submit', ['_secure' => true]);
    }

    /**
     * EnabledAttachment function
     *
     * @param ScopeConfigInterface $scope
     * @return integer
     */
    public function enabledAttachment($scope = ScopeConfigInterface::SCOPE_TYPE_DEFAULT)
    {
        return $this->scopeConfig->isSetFlag(
            'lrcontact/general/email_attachment',
            $scope
        );
    }
}

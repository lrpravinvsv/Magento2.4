<?php

namespace Logicrays\Contact\Controller\Index;

use Magento\Framework\App\Action\HttpPostActionInterface as HttpPostActionInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Logicrays\Contact\Model\ContactFactory;
use Logicrays\Contact\Model\MailInterface;
use Magento\Framework\DataObject;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Filesystem;
use Magento\Framework\Message\ManagerInterface;

class Submit extends \Magento\Framework\App\Action\Action implements HttpPostActionInterface
{
    /**
     * messageManager variable
     *
     * @var string
     */
    protected $messageManager;

    /**
     * MailInterface variable
     *
     * @var integer
     */
    private $mail;

    /**
     * ContactFactory variable
     *
     * @var Logicrays\Contact\Model\ContactFactory
     */
    protected $contactFactory;

    /**
     * FileSystem variable
     *
     * @var string
     */
    private $fileSystem;

    /**
     * __construct function
     *
     * @param ManagerInterface $messageManager
     * @param MailInterface $mail
     * @param ContactFactory $contactFactory
     * @param Context $context
     * @param Filesystem $fileSystem
     */
    public function __construct(
        ManagerInterface $messageManager,
        MailInterface $mail,
        ContactFactory $contactFactory,
        Context $context,
        Filesystem $fileSystem
    ) {
        parent::__construct($context);
        $this->contactFactory = $contactFactory;
        $this->fileSystem = $fileSystem;
        $this->mail = $mail;
        $this->messageManager = $messageManager;
    }

    /**
     * Execute function
     *
     * @return void
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();

        if ($data) {

            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

            $model = $this->contactFactory->create();
            
            if ($_FILES['attachment']['name']) {
                try {
                    $uploader = $this->_objectManager->create(
                        \Magento\MediaStorage\Model\File\Uploader::class,
                        ['fileId' => 'attachment']
                    );
                    // $extesion = pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION);
                    // echo $extesion;
                    // $allowed = array('jpg', 'jpeg', 'doc', 'docx', 'pdf', 'zip', 'png');
                    // if (!in_array($extesion, $allowed)) {
                    //     return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                    // }
                    $uploader->setAllowedExtensions(['jpg', 'jpeg', 'doc', 'docx', 'pdf', 'zip', 'png']);
                    $uploader->setAllowRenameFiles(true);
                    $uploader->setFilesDispersion(true);

                    $mediaDirectory = $this->fileSystem->getDirectoryRead(DirectoryList::MEDIA);
                    $path = $mediaDirectory->getAbsolutePath('lrcontact');
                    $imagePath = $uploader->save($path);

                    $data['attachment'] = $imagePath['file'];

                    $filePath = $imagePath['path'].$imagePath['file'];
                    $fileName = $imagePath['name'];
                    $fileType = $imagePath['type'];

                } catch (Exception $e) {
                    $this->messageManager->addException($e->getMessage());
                    return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                }
            } else {
                $filePath = '';
                $fileName = '';
                $fileType = '';
            }

            $model->setData($data);

            try {
                $this->sendEmail($this->validatedParams(), $filePath, $fileName, $fileType);

                $model->save();
                $this->messageManager->addSuccess(__('Your Request Sent Successfully.'));

                return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
            } catch (\Exception $e) {
                $this->messageManager->addException($e->getMessage());
            }
            return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        } else {
            $this->messageManager->addError(__('Invalid request. Please contact administrator.'));
        }
        return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
    }

    /**
     * SendEmail function
     *
     * @param var $post
     * @param var $filePath
     * @param var $fileName
     * @param var $fileType
     * @return string
     */
    private function sendEmail($post, $filePath, $fileName, $fileType)
    {
        $this->mail->send(
            $post['email'],
            $filePath,
            $fileName,
            $fileType,
            ['data' => new DataObject($post)]
        );
    }

    /**
     * ValidatedParams function
     *
     * @return void
     */
    private function validatedParams()
    {
        $request = $this->getRequest();

        return $request->getParams();
    }
}

<?php
namespace Logicrays\Contact\Controller\Index;

use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;

class Country extends \Magento\Framework\App\Action\Action implements HttpGetActionInterface
{
       /**
        * PageFactory variable
        *
        * @var \Magento\Framework\View\Result\PageFactory
        */
        protected $resultPageFactory;
        /**
         * JsonFactory variable
         *
         * @var \Magento\Framework\Controller\Result\JsonFactory
         */
        protected $resultJsonFactory;
        /**
         * RegionFactory variable
         *
         * @var \Magento\Directory\Model\RegionFactory
         */
        protected $regionColFactory;
        /**
         * __construct function
         *
         * @param \Magento\Framework\App\Action\Context $context
         * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
         * @param \Magento\Directory\Model\RegionFactory $regionColFactory
         * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
         */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Directory\Model\RegionFactory $regionColFactory,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->regionColFactory     = $regionColFactory;
        $this->resultJsonFactory     = $resultJsonFactory;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    /**
     * Execute function
     *
     * @return Array()
     */
    public function execute()
    {
        $this->_view->loadLayout();
        $this->_view->getLayout()->initMessages();
        $this->_view->renderLayout();
 
        $result           = $this->resultJsonFactory->create();
        $regions = $this->regionColFactory->create()
                        ->getCollection()
                        ->addFieldToFilter('country_id', $this->getRequest()->getParam('country'));
         
        $html = '';
         
        if (count($regions) > 0) {
            $html.='<option selected="selected" value="">Please select a region, state or province.</option>';
            foreach ($regions as $state) {
                $html.=    '<option  value="'.$state->getName().'">'.$state->getName().'.</option>';
            }
        }
        return $result->setData(['success' => true,'value'=>$html]);
    }
}

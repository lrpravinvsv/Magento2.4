<?php
namespace Logicrays\Contact\Controller\Adminhtml\Contact;

use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\Filesystem\DirectoryList;
use Logicrays\Contact\Model\ContactFactory;

class Download extends Action implements HttpGetActionInterface
{
    /**
     * ContactFactory variable
     *
     * @var Array
     */
    public $contactFactory;
    
    /**
     * __construct function
     *
     * @param Context $context
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory
     * @param \Magento\Framework\Filesystem\DirectoryList $directory
     * @param \Logicrays\Contact\Model\ContactFactory $contactFactory
     */
    public function __construct(
        Context $context,
        FileFactory $fileFactory,
        DirectoryList $directory,
        ContactFactory $contactFactory
    ) {
        $this->contactFactory = $contactFactory;
        $this->_downloader = $fileFactory;
        $this->directory = $directory;
        parent::__construct($context);
    }

    /**
     * Execute function
     *
     * @return void
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('id');
        try {
            $contactModel = $this->contactFactory->create();
            $contactModel->load($id);
            $fileName = $contactModel->getAttachment();
            $file = $this->directory->getPath("media")."/lrcontact/".$fileName;
            
            return $this->_downloader->create(
                $fileName,
                @file_get_contents($file)
            );
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
        return $resultRedirect->setPath('*/*/');
    }

    /**
     * _isAllowed function
     *
     * @return void
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Logicrays_Contact::download');
    }
}

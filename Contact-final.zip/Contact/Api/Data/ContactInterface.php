<?php

namespace Logicrays\Contact\Api\Data;

interface ContactInterface
{
    public const ID = 'id';
    public const FIRSTNAME = 'firstname';
    public const LASTNAME = 'lastname';
    public const EMAIL = 'email';
    public const PHONE = 'phone';
    public const STREET = 'street';
    public const CITY = 'city';
    public const REGION = 'region';
    public const COUNTRY_ID = 'country_id';
    public const ZIPCODE = 'zipcode';
    public const MESSAGE = 'message';
    public const ATTACHMENT = 'attachment';
    public const CREATED_AT = 'created_at';
    public const UPDATED_AT = 'updated_at';

   /**
    * Get Id.
    *
    * @return int
    */
    public function getId();

   /**
    * SetId function
    *
    * @param var $id
    * @return integer
    */
    public function setId($id);

   /**
    * Get Firstname.
    *
    * @return varchar
    */
    public function getFirstname();

   /**
    * SetFirstname function
    *
    * @param var $firstname
    * @return varchar
    */
    public function setFirstname($firstname);

    /**
     * Get Lastname.
     *
     * @return varchar
     */
    public function getLastname();

   /**
    * SetLastname function
    *
    * @param var $lastname
    * @return varchar
    */
    public function setLastname($lastname);

   /**
    * Get Email.
    *
    * @return varchar
    */
    public function getEmail();

   /**
    * SetEmail function
    *
    * @param var $email
    * @return varchar
    */
    public function setEmail($email);

   /**
    * Get Phone.
    *
    * @return varchar
    */
    public function getPhone();

   /**
    * SetPhone function
    *
    * @param var $phone
    * @return varchar
    */
    public function setPhone($phone);

   /**
    * Get Street.
    *
    * @return varchar
    */
    public function getStreet();

   /**
    * SetStreet function
    *
    * @param var $street
    * @return varchar
    */
    public function setStreet($street);

   /**
    * Get City.
    *
    * @return varchar
    */
    public function getCity();

   /**
    * SetCity function
    *
    * @param var $city
    * @return varchar
    */
    public function setCity($city);

    /**
     * Get Region.
     *
     * @return varchar
     */
    public function getRegion();

   /**
    * SetRegion function
    *
    * @param var $region
    * @return varchar
    */
    public function setRegion($region);

    /**
     * Get Country Id.
     *
     * @return varchar
     */
    public function getCountryId();

   /**
    * SetCountryId function
    *
    * @param var $countryId
    * @return varchar
    */
    public function setCountryId($countryId);

    /**
     * Get Zipcode.
     *
     * @return varchar
     */
    public function getZipcode();

   /**
    * SetZipcode function
    *
    * @param var $zipcode
    * @return varchar
    */
    public function setZipcode($zipcode);

    /**
     * Get Message.
     *
     * @return varchar
     */
    public function getMessage();

   /**
    * SetMessage function
    *
    * @param var $message
    * @return varchar
    */
    public function setMessage($message);
    
    /**
     * Get Attachment.
     *
     * @return varchar
     */
    public function getAttachment();

    /**
     * SetAttachment function
     *
     * @param var $attachment
     * @return varchar
     */
    public function setAttachment($attachment);

   /**
    * Get CreatedAt.
    *
    * @return varchar
    */
    public function getCreatedAt();

   /**
    * SetCreatedAt function
    *
    * @param var $createdAt
    * @return varchar
    */
    public function setCreatedAt($createdAt);

    /**
     * Get UpdatedAt.
     *
     * @return varchar
     */
    public function getUpdatedAt();

   /**
    * SetUpdatedAt function
    *
    * @param var $updatedAt
    * @return varchar
    */
    public function setUpdatedAt($updatedAt);
}

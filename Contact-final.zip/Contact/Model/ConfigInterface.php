<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Logicrays\Contact\Model;

/**
 * Contact module configuration
 *
 * @api
 * @since 100.2.0
 */
interface ConfigInterface
{
    /**
     * Recipient email config path
     */
    public const XML_PATH_EMAIL_COPY_TO = 'lrcontact/general/email_copy_to';

    /**
     * Sender email config path
     */
    public const XML_PATH_EMAIL_SENDER = 'lrcontact/general/sender';

    /**
     * Email admin template config path
     */
    public const XML_PATH_ADMIN_EMAIL_TEMPLATE = 'lrcontact/general/admin_email_template';

    /**
     * Email customer template config path
     */
    public const XML_PATH_CUSTOMER_EMAIL_TEMPLATE = 'lrcontact/general/customer_email_template';

    /**
     * Enabled config path
     */
    public const XML_PATH_ENABLED = 'lrcontact/general/enable';

    /**
     * Enabled Email config path
     */
    public const XML_PATH_EMAIL_ENABLED = 'lrcontact/general/enable_email';

    /**
     * Enabled email attachment path
     */
    public const XML_PATH_ATTACHMENT_ENABLED = 'lrcontact/general/email_attachment';

    /**
     * Check if contact module is enabled
     *
     * @return bool
     * @since 100.2.0
     */
    public function isEnabled();

    /**
     * Check if contact Email is enabled
     *
     * @return bool
     * @since 100.2.0
     */
    public function isEmailEnabled();

    /**
     * Check if email attachment is enabled
     *
     * @return bool
     * @since 100.2.0
     */
    public function emailAttachment();

    /**
     * Return admin email template identifier
     *
     * @return string
     * @since 100.2.0
     */
    public function adminEmailTemplate();

    /**
     * Return customer email template identifier
     *
     * @return string
     * @since 100.2.0
     */
    public function customerEmailTemplate();

    /**
     * Return email sender address
     *
     * @return string
     * @since 100.2.0
     */
    public function emailSender();

    /**
     * Return email recipient address
     *
     * @return string
     * @since 100.2.0
     */
    public function emailCopyTo();
}

<?php

namespace Logicrays\Contact\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

/**
 * Contact module configuration
 */
class Config implements ConfigInterface
{
    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * IsEnabled function
     *
     * @return boolean
     */
    public function isEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_ENABLED,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * isEmailEnabled function
     *
     * @return boolean
     */
    public function isEmailEnabled()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_EMAIL_ENABLED,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * EmailAttachment function
     *
     * @return boolean
     */
    public function emailAttachment()
    {
        return $this->scopeConfig->isSetFlag(
            self::XML_PATH_ATTACHMENT_ENABLED,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * AdminEmailTemplate function
     *
     * @return string
     */
    public function adminEmailTemplate()
    {
        return $this->scopeConfig->getValue(
            ConfigInterface::XML_PATH_ADMIN_EMAIL_TEMPLATE,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * CustomerEmailTemplate function
     *
     * @return string
     */
    public function customerEmailTemplate()
    {
        return $this->scopeConfig->getValue(
            ConfigInterface::XML_PATH_CUSTOMER_EMAIL_TEMPLATE,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * EmailSender function
     *
     * @return string
     */
    public function emailSender()
    {
        return $this->scopeConfig->getValue(
            ConfigInterface::XML_PATH_EMAIL_SENDER,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * EmailCopyTo function
     *
     * @return string
     */
    public function emailCopyTo()
    {
        return $this->scopeConfig->getValue(
            ConfigInterface::XML_PATH_EMAIL_COPY_TO,
            ScopeInterface::SCOPE_STORE
        );
    }
}

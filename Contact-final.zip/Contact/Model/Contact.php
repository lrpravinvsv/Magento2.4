<?php

namespace Logicrays\Contact\Model;

use Logicrays\Contact\Api\Data\ContactInterface;

class Contact extends \Magento\Framework\Model\AbstractModel implements ContactInterface
{
    /**
     * CMS page cache tag.
     */
    public const CACHE_TAG = 'logicrays_contact';

    /**
     * @var string
     */
    protected $_cacheTag = 'logicrays_contact';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'logicrays_contact';

    /**
     * _construct function
     *
     * @return Initialize resource model
     */
    protected function _construct()
    {
        $this->_init(\Logicrays\Contact\Model\ResourceModel\Contact::class);
    }
    /**
     * Get Id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * SetId function
     *
     * @param var $id
     * @return integer
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * Get Firstname.
     *
     * @return varchar
     */
    public function getFirstname()
    {
        return $this->getData(self::FIRSTNAME);
    }

    /**
     * SetFirstname function
     *
     * @param [var $firstname
     * @return string
     */
    public function setFirstname($firstname)
    {
        return $this->setData(self::FIRSTNAME, $firstname);
    }

    /**
     * Get Lastname.
     *
     * @return varchar
     */
    public function getLastname()
    {
        return $this->getData(self::LASTNAME);
    }

    /**
     * SetLastname function
     *
     * @param var $lastname
     * @return string
     */
    public function setLastname($lastname)
    {
        return $this->setData(self::LASTNAME, $lastname);
    }

    /**
     * Get Email.
     *
     * @return varchar
     */
    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

    /**
     * SetEmail function
     *
     * @param var $email
     * @return string
     */
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    /**
     * Get Phone.
     *
     * @return varchar
     */
    public function getPhone()
    {
        return $this->getData(self::PHONE);
    }

    /**
     * SetPhone function
     *
     * @param var $phone
     * @return integer
     */
    public function setPhone($phone)
    {
        return $this->setData(self::PHONE, $phone);
    }

    /**
     * Get Street.
     *
     * @return varchar
     */
    public function getStreet()
    {
        return $this->getData(self::STREET);
    }

    /**
     * SetStreet function
     *
     * @param var $street
     * @return string
     */
    public function setStreet($street)
    {
        return $this->setData(self::STREET, $street);
    }

    /**
     * Get City.
     *
     * @return varchar
     */
    public function getCity()
    {
        return $this->getData(self::CITY);
    }

    /**
     * SetCity function
     *
     * @param var $city
     * @return string
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }

    /**
     * Get Region.
     *
     * @return varchar
     */
    public function getRegion()
    {
        return $this->getData(self::REGION);
    }

    /**
     * SetRegion function
     *
     * @param var $region
     * @return string
     */
    public function setRegion($region)
    {
        return $this->setData(self::REGION, $region);
    }

    /**
     * Get CountryId.
     *
     * @return varchar
     */
    public function getCountryId()
    {
        return $this->getData(self::COUNTRY_ID);
    }

    /**
     * SetCountryId function
     *
     * @param var $countryId
     * @return string
     */
    public function setCountryId($countryId)
    {
        return $this->setData(self::COUNTRY_ID, $countryId);
    }

    /**
     * Get Zipcode.
     *
     * @return varchar
     */
    public function getZipcode()
    {
        return $this->getData(self::ZIPCODE);
    }

    /**
     * SetZipcode function
     *
     * @param var $zipcode
     * @return integer
     */
    public function setZipcode($zipcode)
    {
        return $this->setData(self::ZIPCODE, $zipcode);
    }

    /**
     * Get Message.
     *
     * @return varchar
     */
    public function getMessage()
    {
        return $this->getData(self::MESSAGE);
    }

    /**
     * SetMessage function
     *
     * @param var $message
     * @return string
     */
    public function setMessage($message)
    {
        return $this->setData(self::MESSAGE, $message);
    }

    /**
     * Get Attachment.
     *
     * @return varchar
     */
    public function getAttachment()
    {
        return $this->getData(self::ATTACHMENT);
    }

    /**
     * SetAttachment function
     *
     * @param var $attachment
     * @return string
     */
    public function setAttachment($attachment)
    {
        return $this->setData(self::ATTACHMENT, $attachment);
    }

    /**
     * Get CreatedAt.
     *
     * @return varchar
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * SetCreatedAt function
     *
     * @param var $createdAt
     * @return date
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get UpdatedAt.
     *
     * @return varchar
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * SetUpdatedAt function
     *
     * @param var $updatedAt
     * @return date
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }
}

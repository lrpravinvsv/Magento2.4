<?php

namespace Logicrays\Contact\Model;

use Psr\Log\LoggerInterface;

use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Area;
use Zend\Mime\Mime;
use Magento\Framework\Filesystem\DirectoryList;

class Mail implements MailInterface
{
    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * Dir variable
     *
     * @var string
     */
    protected $dir;

    /**
     * @var ConfigInterface
     */
    private $contactsConfig;

    /**
     * @var TransportBuilder
     */
    private $transportBuilder;

    /**
     * @var StateInterface
     */
    private $inlineTranslation;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * Initialize dependencies.
     *
     * @param DirectoryList $dir
     * @param ConfigInterface $contactsConfig
     * @param TransportBuilder $transportBuilder
     * @param StateInterface $inlineTranslation
     * @param StoreManagerInterface|null $storeManager
     */
    public function __construct(
        LoggerInterface $logger,
        DirectoryList $dir,
        ConfigInterface $contactsConfig,
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation,
        StoreManagerInterface $storeManager = null
    ) {
        $this->logger = $logger;
        $this->dir = $dir;
        $this->contactsConfig = $contactsConfig;
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->storeManager = $storeManager ?: ObjectManager::getInstance()->get(StoreManagerInterface::class);
    }

    /**
     * Send function
     *
     * @param var $replyTo
     * @param var $filePath
     * @param var $fileName
     * @param var $fileType
     * @param array $variables
     * @return string
     */
    public function send($replyTo, $filePath, $fileName, $fileType, array $variables)
    {
        $emailEnabled = $this->contactsConfig->isEmailEnabled();
        $this->logger->info('emailEnabled ');
        $this->logger->info($emailEnabled);
        if ($emailEnabled==1) {
            $emailAttachmentEnabled = $this->contactsConfig->emailAttachment();
            $replyToName = !empty($variables['data']['firstname']) ? $variables['data']['firstname'] : null;

            //send mail to admin with attachment
            $this->inlineTranslation->suspend();
            try {
                $transport = $this->transportBuilder
                    ->setTemplateIdentifier($this->contactsConfig->adminEmailTemplate())
                    ->setTemplateOptions(
                        [
                            'area' => Area::AREA_FRONTEND,
                            'store' => $this->storeManager->getStore()->getId()
                        ]
                    )
                    ->setTemplateVars($variables)
                    ->setFrom($this->contactsConfig->emailSender())
                    ->addTo($this->contactsConfig->emailCopyTo())
                    ->setReplyTo($replyTo, $replyToName);
                if ($emailAttachmentEnabled==1) {
                    $transport->addAttachment(file_get_contents($filePath), $fileName, $fileType);
                }
                $transport->getTransport()->sendMessage();

            } finally {
                $this->inlineTranslation->resume();
            }
            
            // sending email to customer
            $this->inlineTranslation->suspend();
            try {
                $transport = $this->transportBuilder
                    ->setTemplateIdentifier($this->contactsConfig->customerEmailTemplate())
                    ->setTemplateOptions(
                        [
                            'area' => Area::AREA_FRONTEND,
                            'store' => $this->storeManager->getStore()->getId()
                        ]
                    )
                    ->setTemplateVars($variables)
                    ->setFrom($this->contactsConfig->emailSender())
                    ->addTo($replyTo)
                    ->getTransport();

                $transport->sendMessage();

            } finally {
                $this->inlineTranslation->resume();
            }
        }
    }
}

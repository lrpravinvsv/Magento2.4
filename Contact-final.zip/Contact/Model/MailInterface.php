<?php

namespace Logicrays\Contact\Model;

/**
 * Email from contact form
 *
 */
interface MailInterface
{
    /**
     * Send function
     *
     * @param var $replyTo
     * @param var $filePath
     * @param var $fileName
     * @param var $fileType
     * @param array $variables
     * @return array and string
     */
    public function send($replyTo, $filePath, $fileName, $fileType, array $variables);
}

<?php
namespace Logicrays\Contact\Model\ResourceModel\Contact;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
 
class Collection extends AbstractCollection
{
    /**
     * _construct function
     *
     * @return array
     */
    protected function _construct()
    {
        $this->_init(
            \Logicrays\Contact\Model\Contact::class,
            \Logicrays\Contact\Model\ResourceModel\Contact::class
        );
    }
}
